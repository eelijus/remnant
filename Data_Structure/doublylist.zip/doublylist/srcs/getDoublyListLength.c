#include "doublylist.h"

int getDoublyListLength(DoublyList* pList)
{
  return(pList->currentElementCount);
}